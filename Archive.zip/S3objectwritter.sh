#!/bin/bash
########################
# author : Nirakar
# date   : 10 june 2020
########################
#---- read variables

source "$1"


jar_path="${jar_path}"
oracle_connection="${oracle_connection}"
user="${oracle_user}"
password="${oracle_password}"
metadata_path="${metadata_path}"
meta_file_name="${meta_file_name}"
extension="${image_extension}"
sql="${sql_query}"
s3_end_point="${s3_end_point}"
access_key="${access_key}"
secret_key="${secret_key}"
bucket_name="${bucket_name}"


error_exit()
{
    if [ "$?" != "0" ]; then
        echo "$1"
        exit 1
    else 
        echo "Image Extraction successful: Please check following Path for Metadata: "${metadata_path}
    fi
}

java -jar "${jar_path}"  "${oracle_connection}"  "${user}" "${password}" "${metadata_path}" "${meta_file_name}" "${extension}" "${sql}" "${s3_end_point}" "${access_key}" "${secret_key}" "${bucket_name}"

error_exit "S3 object Upload Failed "
